The documentation for P7 Huff can be found in the link below

https://coursework.cs.duke.edu/201-public-documentation/p7-huffman/-/blob/main/README.md
